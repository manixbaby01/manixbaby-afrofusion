export default function ManixBabyWebsite() {
  return (
    <div className="min-h-screen bg-black text-white font-sans">
      <section className="relative flex flex-col items-center justify-center text-center min-h-screen px-6 bg-gradient-to-br from-purple-900 via-black to-gray-900">
        <div className="max-w-4xl">
          <p className="uppercase tracking-[8px] text-purple-300 mb-4 text-sm">
            Afro-Fusion Artist • Performer • Creative Visionary
          </p>

          <h1 className="text-6xl md:text-8xl font-black mb-6">
            MANIX BABY
          </h1>

          <p className="text-lg md:text-2xl text-gray-300 leading-relaxed max-w-3xl mx-auto">
            Congolese-born Afro-fusion artist blending Afrobeat, rap,
            Afro-pop, and modern global sounds into energetic music and
            unforgettable performances.
          </p>

          <div className="flex flex-wrap gap-4 justify-center mt-10">
            <a
              href="https://instagram.com/manixbaby"
              target="_blank"
              className="px-8 py-4 rounded-2xl bg-purple-600 hover:bg-purple-500 transition text-lg font-semibold"
            >
              Follow on Instagram
            </a>

            <a
              href="mailto:manixbaby9@gmail.com"
              className="px-8 py-4 rounded-2xl border border-white hover:bg-white hover:text-black transition text-lg font-semibold"
            >
              Book MANIX BABY
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
